INSERT  
INTO VICTIM(CertNum, AccidentNum, VehicleType) 
VALUES('990609-2000001','2019010101', '보행자');

INSERT   
INTO VICTIM(CertNum, AccidentNum, VehicleType) 
VALUES('990608-1000002','2019010102', '승용차');

INSERT   
INTO VICTIM(CertNum, AccidentNum, VehicleType) 
VALUES('970609-1000005','2019010103', '사륜오토바이');

INSERT   
INTO VICTIM(CertNum, AccidentNum, VehicleType) 
VALUES('900509-1000004','2019010104', '보행자');

INSERT   
INTO VICTIM(CertNum, AccidentNum, VehicleType) 
VALUES('910509-1000004','2019010105', '보행자');

INSERT   
INTO VICTIM(CertNum, AccidentNum, VehicleType) 
VALUES('910519-1000001','2019010201', '화물차');

INSERT   
INTO VICTIM(CertNum, AccidentNum, VehicleType) 
VALUES('830219-1000001','2019010201', '화물차');

INSERT  
INTO VICTIM(CertNum, AccidentNum, VehicleType) 
VALUES('880519-1000001','2019010202', '승용차');

INSERT   
INTO VICTIM(CertNum, AccidentNum, VehicleType) 
VALUES('850519-1000001','2019010203', '보행자');

INSERT   
INTO VICTIM(CertNum, AccidentNum, VehicleType) 
VALUES('830209-1000011','2019010204', '승용차');

INSERT   
INTO VICTIM(CertNum, AccidentNum, VehicleType) 
VALUES('800207-1000011','2019010205', '보행자');

INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('800207-1000012',2019010206, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('800207-1000013',2019010207, '자전거');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('800207-1000014',2019010208, '자전거');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('800507-1000011',2019010209, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('800207-1050011',2019010210, '보행자');
/*목*/
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('810207-1060011',2019010301, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('690207-1070011',2019010302, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('770207-1081013',2019010303, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('060207-2000041',2019010304, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('800206-2009014',2019010305, '화물차');

/*금*/
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('660207-1000011',2019010401, '승용차');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('670207-1000011',2019010402, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('680207-1000011',2019010403, '승용차');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('690207-2000011',2019010404, '승용차');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('800207-2000011',2019010405, '보행자');

/*토*/
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('500207-2000041',2019010501, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('510207-2000051',2019010502, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('520207-2000061',2019010503, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('530207-2000071',2019010504, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('540207-2000081',2019010505, '화물차');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('550207-2000091',2019010506, '화물차');

/*일*/
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('000207-1000011',2019010601, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('000205-1000011',2019010602, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('000407-1000061',2019010603, '특수차');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('011107-1000011',2019010604, '승용차');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('010207-1000011',2019010605, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('021207-2000011',2019010606, '승용차');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('030507-2000011',2019010607, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('030207-2000011',2019010608, '보행자');
INSERT   INTO   VICTIM(CertNum, AccidentNum, VehicleType) values('040207-1000011',2019010609, '보행자');