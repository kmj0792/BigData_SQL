INSERT 
INTO DATEandTIME(WhenDate,WhenTime,WhenDay,AccidentNum)
VALUES('2019-01-01','야','화','2019010101');

INSERT 
INTO DATEandTIME(WhenDate,WhenTime,WhenDay,AccidentNum)
VALUES('2019-01-01','야','화','2019010102');

INSERT 
INTO DATEandTIME(WhenDate,WhenTime,WhenDay,AccidentNum)
VALUES('2019-01-01','주','화','2019010103');

INSERT 
INTO DATEandTIME(WhenDate,WhenTime,WhenDay,AccidentNum)
VALUES('2019-01-01','야','화','2019010104');

INSERT 
INTO DATEandTIME(WhenDate,WhenTime,WhenDay,AccidentNum)
VALUES('2019-01-01','야','화','2019010105');

INSERT 
INTO DATEandTIME(WhenDate,WhenTime,WhenDay,AccidentNum)
VALUES('2019-01-02','야','수','2019010201');
INSERT 
INTO DATEandTIME(WhenDate,WhenTime,WhenDay,AccidentNum)
VALUES('2019-01-02','주','수','2019010202');

INSERT 
INTO DATEandTIME(WhenDate,WhenTime,WhenDay,AccidentNum)
VALUES('2019-01-02','주','수','2019010203');

INSERT 
INTO DATEandTIME(WhenDate,WhenTime,WhenDay,AccidentNum)
VALUES('2019-01-02','주','수',2019010204);

INSERT 
INTO DATEandTIME(WhenDate,WhenTime,WhenDay,AccidentNum)
VALUES('2019-01-02','주','수',2019010205);

INSERT   
INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) 
values('2019-01-02','주', '수', 2019010206);

INSERT   
INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) 
values('2019-01-02','야', '수', 2019010207);

INSERT   
INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) 
values('2019-01-02','야', '수', 2019010208);

INSERT
INTO  DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) 
values('2019-01-02','야', '수', 2019010209);

INSERT   
INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum)
values('2019-01-02','야', '수', 2019010210);

INSERT   
INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) 
values('2019-01-03','야', '목', 2019010301);

INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-03','주', '목', 2019010302);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-03','주', '목', 2019010303);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-03','주', '목', 2019010304);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-03','야', '목', 2019010305);

INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-04','야', '금', 2019010401);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-04','주', '금', 2019010402);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-04','주', '금', 2019010403);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-04','주', '금', 2019010404);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-04','주', '금', 2019010405);

INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-05','야', '토', 2019010501);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-05','야', '토', 2019010502);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-05','야', '토', 2019010503);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-05','야', '토', 2019010504);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-05','주', '토', 2019010505);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-05','주', '토', 2019010506);

INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-06','야', '일', 2019010601);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-06','야', '일', 2019010602);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-06','주', '일', 2019010603);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-06','주', '일', 2019010604);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-06','주', '일', 2019010605);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-06','주', '일', 2019010606);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-06','야', '일', 2019010607);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-06','야', '일', 2019010608);
INSERT   INTO   DATEandTIME(WhenDate, WhenTime, WhenDAY,AccidentNum) values('2019-01-06','야', '일', 2019010609);