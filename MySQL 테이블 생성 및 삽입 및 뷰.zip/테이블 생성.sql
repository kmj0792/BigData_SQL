create database accident;
USE accident;


CREATE table DATEandTIME (
   WhenDate  DATE,
   WhenTime  CHAR(1),
   WhenDAY  CHAR(3),
   AccidentNum INT,
   PRIMARY KEY(AccidentNum)
    );
    
CREATE table PLACE (
	AREA CHAR(2),
    RoadType  VARCHAR(20),
    LATITUDE DECIMAL(18,9),
    LONGITUDE DECIMAL(18,10),
    AccidentID INT,
    FOREIGN KEY(AccidentID) REFERENCES DATEandTIME(AccidentNum),
    PRIMARY KEY(LATITUDE,LONGITUDE)
    );
    
  
CREATE table VICTIM (
    CertNum CHAR(14),
    AccidentNum INT,
    VehicleType VARCHAR(20),
    FOREIGN KEY(AccidentNum) REFERENCES DATEandTIME(AccidentNum),
    primary key (CertNum)
    );

CREATE table ATTACKER (
    CarNum VARCHAR(20),
    AccidentNum INT,
    VehicleType VARCHAR(20),
    FOREIGN KEY(AccidentNum) REFERENCES DATEandTIME(AccidentNum),
    PRIMARY KEY(CarNum)
    );

CREATE table CAUSE (
   VicType VARCHAR(20),
   AttType VARCHAR(20),
   AccidentType VARCHAR(20),
   Violation VARCHAR(20),
   AttCarNum VARCHAR(20),
   AccidentNum INT,
   FOREIGN KEY(AccidentNum) REFERENCES DATEandTIME(AccidentNum)
    );
    

CREATE TABLE DAMAGE (
   AccidentNum INT,
   AttCarNum VARCHAR(20),
   DeathNum INT,
   InjureNum INT,
   WhenDate DATE,
   FOREIGN KEY(AccidentNum) REFERENCES DATEandTIME(AccidentNum),
   FOREIGN KEY(AttCarNum) REFERENCES ATTACKER(CarNum)
    );


