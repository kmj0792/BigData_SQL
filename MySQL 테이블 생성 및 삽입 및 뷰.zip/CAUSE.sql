INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','기타','중앙선 침범','31가0001',2019010101);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('승용차','승용차','정면충돌','중앙선 침범','31나0002',2019010102);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('사륜오토바이','승용차','측면충돌','안전운전 의무 불이행','31다0003',2019010103);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','횡단중','안전운전 의무 불이행','31라0004',2019010104);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','기타','안전운전 의무 불이행','31마0005',2019010105);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('화물차','특수차','추돌','안전운전 의무 불이행','37구0001',2019010201);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('승용차','승용차','기타','안전운전 의무 불이행','37누0002',2019010202);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','건설기계','횡단중','안전운전 의무 불이행','37두0003',2019010203);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('승용차','자전거','측면충돌','중앙선 침범','37루0004',2019010204);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','화물차','전도','안전운전 의무 불이행','37무0005',2019010205);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','횡단중','안전운전 의무 불이행','37부0001',2019010206);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('자전거','승용차','추돌','안전운전 의무 불이행','37부0002',2019010207);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('자전거','화물차','추돌','안전운전 의무 불이행','37부0003',2019010208);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','기타','안전운전 의무 불이행','37부0004',2019010209);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','기타','안전운전 의무 불이행','37부0005',2019010210);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','공작물충돌','중앙선 침범','37수0001',2019010301);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','도로이탈 기타','안전운전 의무 불이행','37수0002',2019010302);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','화물차','기타','안전운전 의무 불이행','37수0003',2019010303);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승합차','횡단중','안전운전 의무 불이행','37수0004',2019010304);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('화물차','이륜차','정면충돌','신호위반','37수0005',2019010305);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('승용차','자전거','기타','신호위반','37우0001',2019010401);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','화물차','횡단중','안전운전 의무 불이행','37우0002',2019010402);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('승용차','건설기계','기타','안전운전 의무 불이행','37우0003',2019010403);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('승용차','화물차','정면충돌','신호위반','37우0004',2019010404);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','화물차','횡단중','안전운전 의무 불이행','37우0005',2019010405);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','기타','안전운전 의무 불이행','37주0001',2019010501);

INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','공작물충돌','안전운전 의무 불이행','37주0002',2019010502);
INSERT   

INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','차도통행중','안전운전 의무 불이행','37주0003',2019010503);
INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','횡단중','안전운전 의무 불이행','37주0004',2019010504);
INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('화물차','화물차','측면충돌','안전운전 의무 불이행','37주0005',2019010505);
INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('화물차','화물차','추돌','안전운전 의무 불이행','37주0006',2019010506);



INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','도로이탈 추락','안전운전 의무 불이행','37추0001',2019010601);
INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','기타','안전운전 의무 불이행','37추0002',2019010602);
INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('특수차','이륜차','측면충돌','과속','37추0003',2019010603);
INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('승용차','승용차','정면충돌','중앙선 침범','37추0004',2019010604);
INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','원동기장치자전거','전도','안전운전 의무 불이행','37추0005',2019010605);
INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('승용차','화물차','정면충돌','신호위반','37추0006',2019010606);
INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','기타','안전운전 의무 불이행','37추0007',2019010607);
INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','횡단중','안전운전 의무 불이행','37추0008',2019010608);
INSERT   
INTO CAUSE(VicType,AttType,AccidentType,Violation,AttCarNum,AccidentNum) 
VALUES('보행자','승용차','공작물충돌','안전운전 의무 불이행','37추0009',2019010609);