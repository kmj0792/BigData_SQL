INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010101,'31가0001',1,0, '2019-01-01'); 

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010102,'31나0002',1,0,'2019-01-01'); 

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010103,'31다0003',1,0,'2019-01-01'); 

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010104,'31라0004',1,0,'2019-01-01'); 

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010105,'31마0005',1,0,'2019-01-01'); 

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010201,'37구0001',1,1,'2019-01-02'); 

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010202,'37누0002',1,0,'2019-01-02'); 

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010203,'37두0003',1,0,'2019-01-02'); 

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010204,'37루0004',1,0,'2019-01-02'); 

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010205,'37무0005',1,1,'2019-01-02');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010206,'37부0001',1,0,'2019-01-02');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010207,'37부0002',1,0,'2019-01-02');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010208,'37부0003',1,0,'2019-01-02');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010209,'37부0004',1,0,'2019-01-02');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010210,'37부0005',1,0,'2019-01-02');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010301,'37수0001',1,1,'2019-01-03');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010302,'37수0002',1,1,'2019-01-03');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010303,'37수0003',1,1,'2019-01-03');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010304,'37수0004',1,0,'2019-01-03');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010305,'37수0005',1,0,'2019-01-03');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010401,'37우0001',1,0,'2019-01-04');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010402,'37우0002',1,0,'2019-01-04');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010403,'37우0003',1,0,'2019-01-04');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010404,'37우0004',1,0,'2019-01-04');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010405,'37우0005',1,0,'2019-01-04');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010501,'37주0001',1,0,'2019-01-05');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010502,'37주0002',1,1,'2019-01-05');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010503,'37주0003',1,0,'2019-01-05');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010504,'37주0004',1,0,'2019-01-05');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010505,'37주0005',1,0,'2019-01-05');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010506,'37주0006',1,0,'2019-01-05');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010601,'37추0001',1,1,'2019-01-06');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010602,'37추0002',1,1,'2019-01-06');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010603,'37추0003',1,0,'2019-01-06');


INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010604,'37추0004',1,0,'2019-01-06');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010605,'37추0005',1,2,'2019-01-06');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010606,'37추0006',1,0,'2019-01-06');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010607,'37추0007',1,0,'2019-01-06');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010608,'37추0008',1,0,'2019-01-06');

INSERT   
INTO DAMAGE(AccidentNum,AttCarNum,DeathNum,InjureNum, WhenDate) 
VALUES(2019010609,'37추0009',1,2,'2019-01-06');
