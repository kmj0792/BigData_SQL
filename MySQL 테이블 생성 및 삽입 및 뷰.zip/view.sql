CREATE VIEW human(accidentnum,VicType,AttType)
AS SELECT		accidentnum,VicType,AttType
from	CAUSE
WHERE	VicType='보행자'
WITH CHECK OPTION;
select *	from	human;

SELECT COUNT(accidentnum) AS "차vs사람 사건수"
FROM	human;

CREATE VIEW vehicle(accidentnum,VicType,AttType)
AS SELECT	Accidentnum,VicType,AttType
from	CAUSE
WHERE	 VicType!='보행자'
WITH CHECK OPTION;
select *	from	vehicle;

SELECT COUNT(accidentnum) AS "차vs차 사건수"
FROM	vehicle;