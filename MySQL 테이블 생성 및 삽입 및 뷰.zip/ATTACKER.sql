INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('31가0001',2019010101, '승용차');

INSERT  
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('31나0002',2019010102, '승용차');

INSERT 
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('31다0003',2019010103, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('31라0004',2019010104, '승용차');

INSERT
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('31마0005',2019010105, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37구0001',2019010201, '특수차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37누0002',2019010202, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37두0003',2019010203, '건설기계');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37루0004',2019010204, '자전거');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37무0005',2019010205, '화물차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37부0001',2019010206, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37부0002',2019010207, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37부0003',2019010208, '화물차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37부0004',2019010209, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37부0005',2019010210, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37수0001',2019010301, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37수0002',2019010302, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37수0003',2019010303, '화물차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37수0004',2019010304, '승합차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37수0005',2019010305, '이륜차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37우0001',2019010401, '자전거');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37우0002',2019010402, '화물차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37우0003',2019010403, '건설기계');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37우0004',2019010404, '화물차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37우0005',2019010405, '화물차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37주0001',2019010501, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37주0002',2019010502, '승용차');


INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37주0003',2019010503, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37주0004',2019010504, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37주0005',2019010505, '화물차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37주0006',2019010506, '화물차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37추0001',2019010601, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37추0002',2019010602, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37추0003',2019010603, '이륜차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37추0004',2019010604, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37추0005',2019010605, '원동기장치자전거');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37추0006',2019010606, '화물차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37추0007',2019010607, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37추0008',2019010608, '승용차');

INSERT   
INTO ATTACKER (CarNum, AccidentNum, VehicleType) 
VALUES('37추0009',2019010609, '승용차');

